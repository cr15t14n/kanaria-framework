function mostrar1(){
	$(document).ready(function(){
		$("#mostrar1").click(function(){
				$("#formulario1").slideToggle();
			});
		});
}
function mostrar2(){
	$(document).ready(function(){
		$("#mostrar2").click(function(){
				$("#formulario2").slideToggle();
			});
		});
}
function mostrar3(){
	$(document).ready(function(){
		$("#mostrar3").click(function(){
				$("#formulario3").slideToggle();
			});
		});
}
function mostrar4(){
	$(document).ready(function(){
		$("#mostrar4").click(function(){
				$("#tabla1").slideToggle();
			});
		});
}
function mostrar5(){
	$(document).ready(function(){
		$("#mostrar5").click(function(){
				$("#tabla2").slideToggle();
			});
		});
}
function mostrar6(){
	$(document).ready(function(){
		$("#mostrar6").click(function(){
				$("#tabla3").slideToggle();
			});
		});
}